import React from 'react';

const Contact = () => {

    return (
        <div className="row">
            <div className="col-12">
                <p>
                    This is a sample contact page just to demonstrate routing demo
                </p>
            </div>
        </div>

    );

}

export { Contact };
