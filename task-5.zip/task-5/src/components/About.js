import React from 'react';

const About = () => {

    return (
        <div className="row">
            <div className="col-12">
                <p>
                    This is a sample about page just to demonstrate routing demo
                </p>
            </div>
        </div>

    );

}

export { About };
