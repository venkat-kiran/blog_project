import React from 'react';

const Home = () => {

    return (
        <div className="row">
            <div className="col-12">
                <p>
                    This is a sample Home page just to demonstrate routing demo
                </p>
            </div>
        </div>

    );

}

export { Home };
