export * from './Contact';
export * from './About';
export * from './Home';
export * from './Navigation';
export * from './Main';
